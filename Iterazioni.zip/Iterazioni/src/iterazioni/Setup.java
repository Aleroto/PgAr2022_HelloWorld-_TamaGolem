package iterazioni;

public class Setup {
	private final static Integer N = 6; /** total elements*/
	

}
